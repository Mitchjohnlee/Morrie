import * as React from "react";
import { Pressable, StyleProp, ViewStyle, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { Border } from "../GlobalStyles";

const FrameIcon = ({ style }) => {
  return (
    <Image
      style={[styles.frameIcon, style]}
      contentFit="cover"
      source={require("../assets/frame-28.png")}
    />
  );
};

const styles = StyleSheet.create({
  frameIcon: {
    borderRadius: Border.br_21xl,
    width: 36,
    height: 34,
  },
});

export default FrameIcon;
