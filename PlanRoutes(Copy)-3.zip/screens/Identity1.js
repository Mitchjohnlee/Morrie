import React, { useState } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import DropDownPicker from "react-native-dropdown-picker";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const Identity1 = () => {
  const [frameDropdownOpen, setFrameDropdownOpen] = useState(false);
  const [frameDropdownValue, setFrameDropdownValue] = useState();
  const [frameDropdownItems, setFrameDropdownItems] = useState([
    { value: "RefCode", label: "RefCode" },
    { value: "dateDgr", label: "dateDgr" },
    { value: "ID", label: "ID" },
  ]);
  const navigation = useNavigation();

  return (
    <View style={styles.identity1}>
      <Image
        style={styles.circlesIcon}
        contentFit="cover"
        source={require("../assets/circles2.png")}
      />
      <Image
        style={styles.identity1Child}
        contentFit="cover"
        source={require("../assets/rectangle-59.png")}
      />
      <View style={[styles.notifBar, styles.notifBarLayout]}>
        <Text style={[styles.text, styles.textLayout]}>9:41</Text>
        <Image
          style={[styles.wifiIcon, styles.notifBarLayout]}
          contentFit="cover"
          source={require("../assets/wifi.png")}
        />
        <Image
          style={[styles.notifBarChild, styles.notifLayout]}
          contentFit="cover"
          source={require("../assets/group-1.png")}
        />
        <Image
          style={[styles.notifBarItem, styles.notifLayout]}
          contentFit="cover"
          source={require("../assets/group-3.png")}
        />
      </View>
      <Text style={styles.companyId}>Company ID</Text>
      <Text style={[styles.listOfAvailable, styles.frameChildPosition]}>
        List of Available sales Order from ERP
      </Text>
      <Text style={styles.totalPrice}>Total Price</Text>
      <Text style={[styles.text1, styles.textTypo]}>770$</Text>
      <Text style={[styles.text2, styles.textTypo]}>4</Text>
      <Text style={styles.totalProducts}>Total Products</Text>
      <Pressable
        style={styles.viewLineItemsWrapper}
        onPress={() => navigation.navigate("Identity2")}
      >
        <Text style={styles.viewLineItems}>View Line Items</Text>
      </Pressable>
      <View
        style={styles.wrapper}
        disableBorderRadius="true"
        showArrowIcon="true"
      >
        <DropDownPicker
          open={frameDropdownOpen}
          setOpen={setFrameDropdownOpen}
          value={frameDropdownValue}
          setValue={setFrameDropdownValue}
          placeholder="Sort by:"
          items={frameDropdownItems}
          labelStyle={styles.frameDropdownValue}
          textStyle={styles.frameDropdownText}
        />
      </View>
      <Image
        style={styles.circlesIcon1}
        contentFit="cover"
        source={require("../assets/circles3.png")}
      />
      <View style={styles.frameParent}>
        <View style={styles.givenIdParent} />
        <View style={[styles.givenIdGroup, styles.frameViewLayout]}>
          <Text style={styles.givenId}>Given ID</Text>
          <Text style={[styles.refcode, styles.refcodeTypo]}>RefCode</Text>
          <Text style={[styles.datedgr, styles.refcodeTypo]}>dateDgr</Text>
          <Image
            style={[styles.frameChild, styles.frameChildPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-51.png")}
          />
          <Pressable style={[styles.removeButton, styles.removeLayout]}>
            <View style={[styles.removeButtonChild, styles.removeLayout]} />
            <Image
              style={[styles.vectorIcon, styles.textLayout]}
              contentFit="cover"
              source={require("../assets/vector.png")}
            />
          </Pressable>
        </View>
        <View style={[styles.givenIdGroup, styles.frameViewLayout]}>
          <Text style={styles.givenId}>Given ID</Text>
          <Text style={[styles.refcode, styles.refcodeTypo]}>RefCode</Text>
          <Text style={[styles.datedgr, styles.refcodeTypo]}>dateDgr</Text>
          <Image
            style={[styles.frameChild, styles.frameChildPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-501.png")}
          />
          <Pressable style={[styles.removeButton, styles.removeLayout]}>
            <View style={[styles.removeButtonChild, styles.removeLayout]} />
            <Image
              style={[styles.vectorIcon, styles.textLayout]}
              contentFit="cover"
              source={require("../assets/vector.png")}
            />
          </Pressable>
        </View>
        <View style={[styles.frameView, styles.frameViewLayout]}>
          <Text style={styles.givenId}>Given ID</Text>
          <Text style={[styles.refcode, styles.refcodeTypo]}>RefCode</Text>
          <Text style={[styles.datedgr, styles.refcodeTypo]}>dateDgr</Text>
          <Pressable style={[styles.removeButton, styles.removeLayout]}>
            <View style={[styles.removeButtonChild, styles.removeLayout]} />
            <Image
              style={[styles.vectorIcon, styles.textLayout]}
              contentFit="cover"
              source={require("../assets/vector.png")}
            />
          </Pressable>
          <Image
            style={[styles.frameChild, styles.frameChildPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-501.png")}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameDropdownValue: {
    color: "#949494",
    fontSize: 14,
    fontWeight: "300",
    fontFamily: "Inter-Light",
  },
  frameDropdownText: {
    color: "#a4a4a4",
    fontFamily: "Inter-Regular",
  },
  notifBarLayout: {
    height: 21,
    position: "absolute",
  },
  textLayout: {
    height: 17,
    position: "absolute",
  },
  notifLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  frameChildPosition: {
    left: 30,
    position: "absolute",
  },
  textTypo: {
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    fontSize: FontSize.size_13xl,
    top: 138,
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  refcodeTypo: {
    width: 172,
    color: Color.colorGray,
    left: 92,
    fontFamily: FontFamily.interLight,
    fontWeight: "300",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  removeLayout: {
    width: 36,
    height: 34,
    position: "absolute",
  },
  frameViewLayout: {
    marginTop: 8,
    width: 349,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    overflow: "hidden",
  },
  circlesIcon: {
    top: -86,
    left: 283,
    width: 256,
    height: 249,
    position: "absolute",
  },
  identity1Child: {
    width: 360,
    height: 34,
    left: 0,
    top: 0,
    position: "absolute",
  },
  text: {
    fontSize: FontSize.size_mini,
    width: 41,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    height: 17,
    left: 0,
    top: 0,
  },
  wifiIcon: {
    left: 313,
    width: 20,
    top: 0,
    height: 21,
    overflow: "hidden",
  },
  notifBarChild: {
    height: "47.62%",
    width: "6.01%",
    top: "28.57%",
    right: "9.31%",
    bottom: "23.81%",
    left: "84.68%",
  },
  notifBarItem: {
    height: "66.67%",
    width: "5.41%",
    top: "14.29%",
    right: "19.22%",
    bottom: "19.05%",
    left: "75.38%",
  },
  notifBar: {
    top: 11,
    width: 333,
    left: 18,
  },
  companyId: {
    height: "1.63%",
    marginLeft: 2458,
    top: "213.5%",
    left: "50%",
    fontSize: FontSize.size_smi,
    width: 118,
    textAlign: "left",
    color: Color.colorBlack,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  listOfAvailable: {
    top: 50,
    fontSize: FontSize.size_xl,
    fontWeight: "800",
    fontFamily: FontFamily.interExtraBold,
    color: Color.colorDarkblue,
    width: 241,
    textAlign: "left",
  },
  totalPrice: {
    left: 219,
    width: 132,
    fontFamily: FontFamily.interLight,
    fontWeight: "300",
    fontSize: FontSize.size_sm,
    top: 116,
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  text1: {
    left: 222,
    width: 109,
  },
  text2: {
    left: 32,
    width: 75,
  },
  totalProducts: {
    left: 31,
    width: 137,
    fontFamily: FontFamily.interLight,
    fontWeight: "300",
    fontSize: FontSize.size_sm,
    top: 116,
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  viewLineItems: {
    color: Color.colorSeagreen,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    fontSize: FontSize.size_sm,
    width: 118,
    textAlign: "left",
  },
  viewLineItemsWrapper: {
    top: 631,
    left: 17,
    backgroundColor: Color.colorMintcream,
    width: 142,
    height: 36,
    flexDirection: "row",
    alignItems: "center",
    paddingLeft: 16,
    paddingRight: 12,
    borderRadius: Border.br_21xl,
    fontWeight: "bold",
    position: "absolute",
  },
  wrapper: {
    top: 188,
    width: 99,
    height: 27,
    borderRadius: 0,
    backfaceVisibility: "hidden",
    left: 18,
    position: "absolute",
  },
  circlesIcon1: {
    top: 677,
    left: 232,
    width: 261,
    height: 255,
    position: "absolute",
  },
  givenIdParent: {
    height: 81,
    width: 349,
    backgroundColor: Color.colorWhite,
    borderRadius: Border.br_3xs,
    overflow: "hidden",
  },
  givenId: {
    top: 8,
    left: 92,
    fontFamily: FontFamily.interBold,
    fontWeight: "700",
    width: 137,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.colorBlack,
    position: "absolute",
  },
  refcode: {
    top: 30,
  },
  datedgr: {
    top: 52,
  },
  frameChild: {
    top: 15,
    width: 47,
    height: 47,
  },
  removeButtonChild: {
    backgroundColor: Color.colorMistyrose,
    borderRadius: Border.br_21xl,
    left: 0,
    width: 36,
    top: 0,
  },
  vectorIcon: {
    top: 9,
    left: 9,
    width: 17,
  },
  removeButton: {
    top: 18,
    left: 305,
  },
  givenIdGroup: {
    height: 81,
  },
  frameView: {
    height: 89,
  },
  frameParent: {
    top: 268,
    left: 5,
    height: 356,
    position: "absolute",
  },
  identity1: {
    backgroundColor: Color.colorWhitesmoke,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default Identity1;
