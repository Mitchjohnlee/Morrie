/* fonts */
export const FontFamily = {
  interLight: "Inter-Light",
  interBold: "Inter-Bold",
  interSemiBold: "Inter-SemiBold",
  interMedium: "Inter-Medium",
  interRegular: "Inter-Regular",
};
/* font sizes */
export const FontSize = {
  size_3xs: 10,
  size_sm: 14,
  size_base: 16,
  size_xs: 12,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorBlack: "#000",
  colorOrangered: "#ff460c",
  colorMediumseagreen: "#05ab52",
  colorDarkblue: "#350f9f",
  colorGainsboro: "#d9d9d9",
};
/* border radiuses */
export const Border = {
  br_8xs: 5,
  br_11xs: 2,
};
