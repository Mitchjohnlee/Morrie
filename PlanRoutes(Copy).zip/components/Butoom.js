import * as React from "react";
import { StyleProp, ViewStyle, StyleSheet, View, Image } from "react-native";
import { Color } from "../GlobalStyles";

const Butoom = ({ style }) => {
  return (
    <View style={[styles.butoom, style]}>
      <View style={styles.butoomChild} />
      <Image
        style={[styles.iconMenu, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/-icon-menu.png")}
      />
      <Image
        style={[styles.iconStop, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/-icon-stop.png")}
      />
      <Image
        style={[styles.iconChevronLeft, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/-icon-chevron-left.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    top: "19.51%",
    overflow: "hidden",
    position: "absolute",
  },
  butoomChild: {
    top: 0,
    left: 0,
    backgroundColor: Color.colorWhite,
    overflow: "hidden",
    position: "absolute",
    height: 41,
    width: 360,
  },
  iconMenu: {
    height: "61.22%",
    width: "5.25%",
    right: "82.81%",
    bottom: "19.27%",
    left: "11.94%",
  },
  iconStop: {
    height: "60.98%",
    width: "6.94%",
    right: "46.39%",
    bottom: "19.51%",
    left: "46.67%",
  },
  iconChevronLeft: {
    height: "63.9%",
    width: "4.17%",
    right: "13.33%",
    bottom: "16.59%",
    left: "82.5%",
  },
  butoom: {
    height: 41,
    width: 360,
  },
});

export default Butoom;
