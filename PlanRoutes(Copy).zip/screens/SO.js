import * as React from "react";
import {
  Image,
  StyleSheet,
  Pressable,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  ImageBackground,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const SO = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.so1}>
      <Image
        style={styles.arrowsChevronLeft}
        resizeMode="cover"
        source={require("../assets/24--arrows--chevronleft.png")}
      />
      <Pressable
        style={[styles.viewLineItemsWrapper, styles.so1ChildPosition]}
        onPress={() => navigation.navigate("SO1")}
      >
        <Text style={[styles.viewLineItems, styles.viewLineItemsClr]}>
          View Line Items
        </Text>
      </Pressable>
      <Text style={[styles.total, styles.totalTypo]}>Total</Text>
      <View
        style={[
          styles.listOfAvailableSalesOrderWrapper,
          styles.wrapperPosition,
        ]}
      >
        <Text style={[styles.listOfAvailable, styles.wrapperPosition]}>
          List of Available sales Order from ERP
        </Text>
      </View>
      <TextInput
        style={[styles.so1Child, styles.so1ChildPosition]}
        placeholder="99999"
        placeholderTextColor="#202020"
      />
      <TouchableOpacity
        style={[styles.wrapper, styles.wrapperPosition]}
        activeOpacity={0.2}
        onLongPress={() => navigation.navigate("SO2")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/frame-2.png")}
        />
      </TouchableOpacity>
      <ImageBackground
        style={styles.so1Item}
        resizeMode="cover"
        source={require("../assets/rectangle4.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  so1ChildPosition: {
    height: 38,
    top: 651,
    position: "absolute",
  },
  viewLineItemsClr: {
    color: Color.colorWhite,
    textAlign: "center",
  },
  totalTypo: {
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  wrapperPosition: {
    left: "50%",
    position: "absolute",
  },
  arrowsChevronLeft: {
    height: "5%",
    width: "11.11%",
    top: "4.88%",
    right: "88.89%",
    bottom: "90.13%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  viewLineItems: {
    top: 9,
    left: 39,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    textAlign: "center",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  viewLineItemsWrapper: {
    left: 3,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.colorMediumseagreen,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 199,
    overflow: "hidden",
  },
  total: {
    top: 632,
    left: 230,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.colorBlack,
    textAlign: "center",
  },
  listOfAvailable: {
    marginLeft: -127.5,
    top: 22,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    textAlign: "center",
    color: Color.colorWhite,
  },
  listOfAvailableSalesOrderWrapper: {
    marginLeft: -181,
    top: 0,
    backgroundColor: Color.colorOrangered,
    width: 361,
    height: 61,
    overflow: "hidden",
  },
  so1Child: {
    left: 228,
    width: 128,
    backgroundColor: "#D9D9D9",
    borderRadius: 10,
  },
  icon: {
    marginLeft: -177,
    height: "100%",
    width: "100%",
  },
  wrapper: {
    top: 192,
    width: 353,
    height: 416,
  },
  so1Item: {
    marginTop: -326,
    top: "50%",
    left: 5,
    width: 346,
    height: 118,
    position: "absolute",
  },
  so1: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default SO;
