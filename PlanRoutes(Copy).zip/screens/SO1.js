import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const SO1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.so2}>
      <Image
        style={[styles.arrowsChevronLeft, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/24--arrows--chevronleft.png")}
      />
      <View style={[styles.lineItemDetailsWrapper, styles.so2ChildPosition]}>
        <Text style={[styles.lineItemDetails, styles.lineItemDetailsTypo]}>
          LINE ITEM DETAILS
        </Text>
      </View>
      <Text style={[styles.salesOrderNumber, styles.lineItemDetailsTypo]}>
        SALES ORDER NUMBER
      </Text>
      <Image
        style={[styles.so2Child, styles.so2ChildPosition]}
        resizeMode="cover"
        source={require("../assets/frame-21.png")}
      />
      <Pressable
        style={[styles.arrowsChevronLeft1, styles.arrowsLayout]}
        onPress={() => navigation.navigate("SO")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/24--arrows--chevronleft1.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  so2ChildPosition: {
    position: "absolute",
    left: "50%",
  },
  lineItemDetailsTypo: {
    textAlign: "center",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  arrowsLayout: {
    width: "11.11%",
    height: "5%",
    position: "absolute",
  },
  arrowsChevronLeft: {
    top: "4.88%",
    right: "88.89%",
    bottom: "90.13%",
    left: "0%",
    width: "11.11%",
    height: "5%",
    position: "absolute",
  },
  lineItemDetails: {
    marginLeft: -74,
    top: 25,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: Color.colorWhite,
    left: "50%",
  },
  lineItemDetailsWrapper: {
    marginLeft: -180,
    top: 0,
    backgroundColor: Color.colorDarkblue,
    width: 360,
    height: 69,
    left: "50%",
    overflow: "hidden",
  },
  salesOrderNumber: {
    top: 79,
    left: 89,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorDarkblue,
  },
  so2Child: {
    marginLeft: -176,
    top: 98,
    width: 353,
    height: 581,
    left: "50%",
  },
  icon: {
    height: "100%",
    backgroundColor: "#D9D9D9",
    borderRadius: 10,
    borderBottomColor: "",
    width: "100%",
  },
  arrowsChevronLeft1: {
    left: "3.33%",
    top: "85.88%",
    right: "85.56%",
    bottom: "9.13%",
  },
  so2: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 800,
    overflow: "hidden",
    width: "100%",
  },
});

export default SO1;
