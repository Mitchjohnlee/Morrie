import React, { useState } from "react";
import {
  Image,
  StyleSheet,
  Pressable,
  Text,
  View,
  TextInput,
  Switch,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const SO2 = () => {
  const [toogleSwitchValueState, setToogleSwitchValueState] = useState(true);
  const navigation = useNavigation();

  return (
    <View style={styles.so3}>
      <Image
        style={styles.arrowsChevronLeft}
        resizeMode="cover"
        source={require("../assets/24--arrows--chevronleft.png")}
      />
      <Pressable
        style={[styles.viewLineItemsWrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("SO1")}
      >
        <Text style={[styles.viewLineItems, styles.viewLineItemsFlexBox]}>
          View Line Items
        </Text>
      </Pressable>
      <Pressable
        style={[styles.startTheJourneyWrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("SO3")}
      >
        <Text style={[styles.startTheJourney, styles.viewLineItemsFlexBox]}>
          Start the Journey
        </Text>
      </Pressable>
      <Text style={[styles.orderId, styles.useGpsTypo]}>Order ID:</Text>
      <Text style={[styles.useGps, styles.useGpsTypo]}>Use GPS</Text>
      <View style={[styles.availableRoutesWrapper, styles.so3Position]}>
        <Text style={[styles.availableRoutes, styles.so3Position]}>
          AVAILABLE ROUTES
        </Text>
      </View>
      <TextInput
        style={styles.textinput}
        placeholder="99999"
        autoCapitalize="characters"
        placeholderTextColor="#202020"
      />
      <Image
        style={[styles.so3Child, styles.so3Position]}
        resizeMode="cover"
        source={require("../assets/frame-6.png")}
      />
      <Switch
        style={styles.toogle}
        value={toogleSwitchValueState}
        onValueChange={setToogleSwitchValueState}
        thumbColor="#fa8802"
        trackColor={{ false: "#939393", true: "#a3a1b1" }}
      />
      <Image
        style={[styles.so3Item, styles.so3Position]}
        resizeMode="cover"
        source={require("../assets/frame-22.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperLayout: {
    height: 38,
    borderRadius: Border.br_8xs,
    width: 353,
    left: 3,
    position: "absolute",
    overflow: "hidden",
  },
  viewLineItemsFlexBox: {
    textAlign: "center",
    color: Color.colorWhite,
  },
  useGpsTypo: {
    color: Color.colorBlack,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    top: 680,
    textAlign: "center",
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  so3Position: {
    left: "50%",
    position: "absolute",
  },
  arrowsChevronLeft: {
    height: "5%",
    width: "11.11%",
    top: "4.88%",
    right: "88.89%",
    bottom: "90.13%",
    left: "0%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  viewLineItems: {
    left: 116,
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
    top: 9,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  viewLineItemsWrapper: {
    top: 317,
    backgroundColor: Color.colorMediumseagreen,
  },
  startTheJourney: {
    left: 110,
    fontFamily: FontFamily.interMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
    top: 9,
    textAlign: "center",
    color: Color.colorWhite,
    position: "absolute",
  },
  startTheJourneyWrapper: {
    top: 710,
    backgroundColor: Color.colorDarkblue,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
  },
  orderId: {
    left: 3,
    color: Color.colorBlack,
  },
  useGps: {
    left: 285,
  },
  availableRoutes: {
    marginLeft: -69,
    top: 22,
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    textAlign: "center",
    color: Color.colorWhite,
  },
  availableRoutesWrapper: {
    marginLeft: -180,
    top: 0,
    backgroundColor: Color.colorOrangered,
    width: 360,
    height: 61,
    overflow: "hidden",
  },
  textinput: {
    left: 82,
    fontFamily: FontFamily.interSemiBold,
    fontWeight: "600",
    top: 680,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  so3Child: {
    marginLeft: -176,
    top: 360,
    height: 311,
    width: 353,
    left: "50%",
  },
  toogle: {
    top: 683,
    left: 247,
    width: 36,
    height: 14,
    position: "absolute",
  },
  so3Item: {
    marginLeft: -177,
    top: 61,
    height: 251,
    width: 353,
    left: "50%",
  },
  so3: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default SO2;
